const db = require("./db")
const express = require('express');
const bodyParser = require('body-parser');

// Create a new user (POST /users)
const app = express();
app.use(bodyParser.json());
// Get all users (GET /users)
app.get('/users', async (req, res) => {
    try {
        const result = await db.getUsers();
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error fetching users' });
    }
});

// Get a single user by ID (GET /users/:id)


// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

app.post('/register', async (req, res) => {
    const { name, email, phone, password } = req.body;
    try {
        const newUser = await db.addUser({ name, email, phone, password });
        res.status(201).json({ message: 'User registered successfully', data: newUser });
    } catch (error) {
        console.error('Registration error:', error.message);
        res.status(500).json({ error: 'Failed to register user' });
    }
});


app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await db.findUserByEmail(email);
        if (user && user.password === password) { // Replace with hashed password check in production
            res.json({ message: 'Login successful' });
        } else {
            res.status(400).json({ error: 'Invalid email or password' });
        }
    } catch (error) {
        console.error('Login error:', error.message);
        res.status(500).json({ error: 'Failed to log in' });
    }
});
console.log