const { Pool } = require('pg');

// Initialize Express and configure it to parse JSON

// Set up PostgreSQL connection
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'tools3',
    password: '12345', // Replace with your PostgreSQL password
    port: 5432,
});

// Test the database connection
pool.connect((err) => {
    if (err) {
        console.error('Database connection error:', err.stack);
    } else {
        console.log('Connected to PostgreSQL');
    }
});

const addUser = async ({ name, email, phone, password }) => {
    const query = `
        INSERT INTO public."User" (name, email, phone_number, password)
        VALUES ($1, $2, $3, $4) RETURNING *;
    `;
    const values = [name, email, phone, password];
    try {
        const result = await pool.query(query, values);
        return result.rows[0];
    } catch (err) {
        console.error("Error adding user:", err.message);
        throw err;
    }
};

const getUsers = async() => {
    try {
        const res = await client.query(`SELECT * FROM public."User" ORDER BY uid ASC`);
        return res.rows;
      } catch (err) {
        console.error("Error retrieving users:", err.message);
        throw err;
      }
};
module.exports = { getUsers };