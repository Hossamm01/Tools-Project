// src/components/Register.js
import React, { useState } from 'react';
import axios from 'axios';

const Register = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        password: '',
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:3000/register', formData);
            alert(response.data.message || 'User registered successfully!');
        } catch (error) {
            // Log error details for easier debugging
            console.log('Error details:', error);
    
            // Improved error handling for different error types
            if (error.response) {
                // Server responded with a status other than 2xx
                console.log('Response error:', error.response.data);
                alert(error.response.data.error || 'Registration failed');
            } else if (error.request) {
                // Request was made but no response received
                console.log('No response received:', error.request);
                alert('No response from server. Check if the backend is running.');
            } else {
                // Other errors (like network issues)
                console.log('Error setting up the request:', error.message);
                alert('Registration failed due to a network issue.');
            }
        }
    };
    
    

    return (
        <div>
            <h2>Register</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
                <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
                <input type="text" name="phone" placeholder="Phone" value={formData.phone} onChange={handleChange} required />
                <input type="password" name="password" placeholder="Password" value={formData.password} onChange={handleChange} required />
                <button type="submit">Register</button>
            </form>
        </div>
    );
};

export default Register;
